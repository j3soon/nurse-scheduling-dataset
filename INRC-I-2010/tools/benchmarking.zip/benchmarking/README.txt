This program is designed to set the time granted to the participant
for the Nurse Rostering Competition.  It is based on the Fhourstones
Benchmark by John Tromp.

The program should be run when the machine is not being used for anything else.

The windows version needs the library cygwin1.dll, which can be placed
in the same folder of the executable or in the system folder, normally
C:\WINDOWS\system32

